public class RBCommunityEvents         // Add your class name here!
{
    // 1. write 3 instance variables for class: private type variableName;
    private String event;
    private String date;
    private String time;


    // 2. Add a constructor with 3 parameters to set all of the instance variables to the given parameters.
    public RBCommunityEvents(String e, String d, String t) 
    {
        event = e;
        date = d;
        time = t;
    }
    
    // 3. Write a print() method that uses System.out.println to print out all the instance variables.
    public void print() 
    {
        System.out.println("Event: " + event);
        System.out.println("Date: " + date);
        System.out.println("Time: " + time);
    }


    // 4. Create accessor (get) methods for each of the instance variables.
    public String getEvent() 
    {
        return event;
    }
    
    public String getDate() 
    {
        return date;
    }
    
    public String getTime() 
    {
        return time;
    }


    // 5. Create mutator (set) methods for each of the instance variables.
    public void setEvent(String newEvent) 
    {
        event = newEvent;
    }
    
    public void setDate(String newDate) 
    {
        date = newDate;
    }
    
    public void setTime(String newTime) 
    {
        time = newTime;
    }


    // 6. Create a toString() method that returns all the information in the instance variables.
    public String toString() 
    {
        return event + ": " + date + ", " + time;
    }


    // 7. Write an additional method for your class that takes a parameter.
    // For example, there could be a print method with arguments that indicate how you want to print out
    // the information, e.g. print(format) could print the data according to an argument that is "plain"
    // or "table" where the data is printed in a table drawn with dashes and lines (|).
    public void print(boolean formatNormal)
    {
        if (formatNormal)
            print(); //print normal format (see print method above)
        else
            System.out.println(event + "|" + date + "|" + time); //output as table 
    }
    
    public boolean withinMonth(String month)
    {
        return date.contains(month);
    }
    
    public static void withinMonth(RBCommunityEvents[] events, String month) 
    {
        for (RBCommunityEvents e : events) 
        {
            if (e.withinMonth(month)) 
            {
                e.print(true);
            }
        }
    }


    // 8. Write a main method that constructs at least 2 objects of your class
    // using the constructor and then calls all of the methods that you created above to test them.
    public static void main(String[] args)
    {
       // Construct 2 objects of your class using the constructor with different values
       RBCommunityEvents e1 = new RBCommunityEvents("Grocery Drive Thru for Salvation Army", "December 6", "9am - 11am");
       RBCommunityEvents e2 = new RBCommunityEvents("Christmas Concert", "December 7", "4pm");
       RBCommunityEvents e3 = new RBCommunityEvents("Christmas Eve family church service", "December 24", "1pm");
       RBCommunityEvents e4 = new RBCommunityEvents("Warm Clothing Closet Clean Out Drive Thru", "January 17", "9am - 11am");
       RBCommunityEvents e5 = new RBCommunityEvents("San Diego Blood Bank Blood Drive", "February 15", "7:30am-12:30pm");
       RBCommunityEvents e6 = new RBCommunityEvents("Orchestra concert series", "February 22", "4pm");

       // call all of the objects methods to test them
       RBCommunityEvents[] events = { e1, e2, e3, e4, e5, e6 };

       withinMonth(events, "December"); 
        

    }
}



