import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;

// Main class with GUI
public class Main {
    // We'll store all events in this list to display them later
    private static ArrayList<RBCommunityEvents> eventList = new ArrayList<>();
    private static JTextArea displayArea;

    public static void main(String[] args) {
        // Create the window
        JFrame frame = new JFrame("RB Community Events Manager");
        frame.setSize(600, 700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Title
        JLabel titleLabel = new JLabel("Add a New Community Event", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        frame.add(titleLabel, BorderLayout.NORTH);

        // Form Panel (center)
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(4, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Form fields
        JLabel eventLabel = new JLabel("Event Name:");
        JTextField eventField = new JTextField(20);

        JLabel dateLabel = new JLabel("Date (e.g. December 6):");
        JTextField dateField = new JTextField(20);

        JLabel timeLabel = new JLabel("Time (e.g. 9am - 11am):");
        JTextField timeField = new JTextField(20);

        JButton addButton = new JButton("Add Event");
        JButton showDecemberButton = new JButton("Show December Events");

        // Add components to form
        formPanel.add(eventLabel);
        formPanel.add(eventField);
        formPanel.add(dateLabel);
        formPanel.add(dateField);
        formPanel.add(timeLabel);
        formPanel.add(timeField);
        formPanel.add(addButton);
        formPanel.add(showDecemberButton);

        frame.add(formPanel, BorderLayout.CENTER);

        // Display area (south)
        displayArea = new JTextArea(20, 50);
        displayArea.setEditable(false);
        displayArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(displayArea);
        frame.add(scrollPane, BorderLayout.SOUTH);

        // Add some sample events on startup
        eventList.add(new RBCommunityEvents("Grocery Drive Thru for Salvation Army", "December 6", "9am - 11am"));
        eventList.add(new RBCommunityEvents("Christmas Concert", "December 7", "4pm"));
        eventList.add(new RBCommunityEvents("Christmas Eve family church service", "December 24", "1pm"));
        eventList.add(new RBCommunityEvents("Warm Clothing Closet Clean Out Drive Thru", "January 17", "9am - 11am"));
        eventList.add(new RBCommunityEvents("San Diego Blood Bank Blood Drive", "February 15", "7:30am-12:30pm"));
        updateDisplay("=== All Events Loaded ===\n");

        // Action: Add new event
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String eventName = eventField.getText().trim();
                String date = dateField.getText().trim();
                String time = timeField.getText().trim();

                if (eventName.isEmpty() || date.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Event name and date are required!", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Create and add the new event
                RBCommunityEvents newEvent = new RBCommunityEvents(eventName, date, time.isEmpty() ? "Time TBD" : time);
                eventList.add(newEvent);

                // Save to file (optional)
                try {
                    FileWriter writer = new FileWriter("community_events.txt", true); // append mode
                    writer.write(newEvent.toString() + "\n");
                    writer.close();
                } catch (IOException ex) {
                    System.out.println("Could not save to file.");
                }

                // Update display and clear fields
                updateDisplay("Added: " + newEvent.toString() + "\n");
                eventField.setText("");
                dateField.setText("");
                timeField.setText("");
                eventField.requestFocus();
            }
        });

        // Action: Show only December events
        showDecemberButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayArea.setText("=== December Events ===\n\n");
                boolean found = false;
                for (RBCommunityEvents event : eventList) {
                    if (event.withinMonth("December")) {
                        displayArea.append(event.toString() + "\n");
                        found = true;
                    }
                }
                if (!found) {
                    displayArea.append("No December events found.\n");
                }
            }
        });

        frame.setVisible(true);
    }

    // Helper method to append text to the display area
    private static void updateDisplay(String text) {
        displayArea.append(text + "\n");
    }
}