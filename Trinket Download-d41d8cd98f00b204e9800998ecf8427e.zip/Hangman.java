import java.util.Scanner;

public class Hangman {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // 1. Computer generates a random word
        int randomNum = (int)(Math.random() * 3) + 1; // 1–3
        String phrase = "";
        if (randomNum == 1) phrase = "A walk in the park";
        else if (randomNum == 2) phrase = "Avengers Assemble";
        else phrase = "Happy Halloween";

        // 2. Create underscores for the secret phrase
        String progress = "";
        int i = 0;
        while (i < phrase.length()) {
            progress += "_";
            i++;
        }

        String guessLetter = "";
        int wrongGuess = 0;
        int maxWrong = 6;
        boolean player1Turn = true; // true = Player 1's turn, false = Player 2's turn

        // 3. Game loop
        while (wrongGuess < maxWrong && progress.contains("_")) {
            System.out.println("\nPhrase: " + progress);
            System.out.println("Wrong guesses left: " + (maxWrong - wrongGuess));
            System.out.println("Guessed letters: " + guessLetter);

            // Tell whose turn it is
            String currentPlayer = player1Turn ? "Player 1" : "Player 2";
            System.out.print(currentPlayer + ", enter a letter: ");
            char guess = input.next().toLowerCase().charAt(0);
            input.nextLine();

            // Check if letter already guessed
            if (guessLetter.indexOf(guess) != -1) {
                System.out.println("Already guessed that letter!");
                continue; // skip to next iteration
            }

            guessLetter += guess;
            boolean found = false;

            // Update progress string
            String newProgress = "";
            int j = 0;
            while (j < phrase.length()) {
                char letter = phrase.charAt(j);
                if (letter == guess) {
                    newProgress += guess;
                    found = true;
                } else {
                    newProgress += progress.charAt(j);
                }
                j++;
            }

            if (found) {
                progress = newProgress;
                System.out.println("Good guess!");
            } else {
                wrongGuess++;
                System.out.println("Wrong guess!");
            }

            // Switch turns
            player1Turn = !player1Turn;
        }

        // 4. End of game
        if (progress.equals(phrase)) {
            // Whoever just guessed last is the winner
            String winner = player1Turn ? "Player 2" : "Player 1";
            System.out.println("\n��� " + winner + " wins! The phrase was: " + phrase);
        } else {
            System.out.println("\n��� No one guessed the phrase! The phrase was: " + phrase);
        }

        input.close();
    }
}
