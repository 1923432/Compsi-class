
public class TargetedAd {

  public static void main(String[] args)
  {
    DataCollector myObject = new DataCollector();
    myObject.setData("socialMediaPosts.txt", "targetWords.txt");

    /*    
     * (3) Create a String variable to hold the names of all the user. (The first word of every post is 
     *     a person's username)
     */
    String users = "";

    /*    
     * (4) Compare each user's post to each target word. If a user mentions a target word, add their username to 
     *     the String of users. Separate usernames with a space. 
     *         Hint: You can use loops to look through each word. 
     *         Hint2: You can use indexOf to check if a word is in a user post. 
     */
    String post = myObject.getNextPost(); //get the first post
    while (post != "NONE") 
    {
      String targetWord = myObject.getNextTargetWord(); //get the first targetWord (this is not the same function as getNextTargetWord)//
      
      while (targetWord != "NONE")
      {
        //compare post to the target words (but only in lower case)
        if (post.toLowerCase().contains(targetWord)) 
        {
          String name = post.split(" ")[0]; //split the post into a list of strings and return the first one which is our username
          users += name + " "; //add the username to our list of users
          targetWord = "NONE"; //we found the user, so stop checking for other targetWords
        }
        else
          targetWord = myObject.getNextTargetWord();
      }
    
      post = myObject.getNextPost();
    }

    /*    
     * (5) Once you have all the users, use your DataCollector's prepareAdvertisement method to prepare a file 
     *     with all users and the advertisement you will send them.
     *         Additional Info: The prepareAdvertisement creates a new file on your computer. Check the posts of
     *         some of the usernames to make sure your algorithm worked. 
     */
    myObject.prepareAdvertisement("targettedAdds.txt", users, "hi animal lover, chewy toys for figety animals on sale now!");
  }

}
